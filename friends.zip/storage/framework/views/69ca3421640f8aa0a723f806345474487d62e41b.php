        <!-- About Section-->
        <section class="page-section bg-primary text-white mb-0" id="about">
            <div class="container">
                <!-- About Section Heading-->
                <h2 class="page-section-heading text-center text-uppercase text-white">Список людей</h2>
                <!-- Icon Divider-->
                <div class="divider-custom divider-light">
                    <div class="divider-custom-line"></div>
                    <div class="divider-custom-icon"><i class="fas fa-star"></i></div>
                    <div class="divider-custom-line"></div>
                </div>
                <!-- About Section Content-->
                <div class="row">
                    <div class="text-center">
                    Список
                    </div>
                 
                </div>
                <!-- About Section Button-->
                <div class="text-center mt-4">
                    <p class="btn btn-xl btn-outline-light" >
                    <i class="fab fa-algolia"></i>
                      Количество  учаников еще не выбрали друга: 0
                   </p>
                   <p class="btn btn-xl btn-outline-light" >
                   <i class="fas fa-bookmark"></i>
                      Количество учаников которые уже выбрали друга: 0
                   </p>
                </div>
            </div>
        </section><?php /**PATH D:\OpenServer\domains\friends\resources\views/design/about.blade.php ENDPATH**/ ?>